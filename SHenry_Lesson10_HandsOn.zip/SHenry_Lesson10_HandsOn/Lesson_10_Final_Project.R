#Load programs and libraries
install.packages("Ecdat")
install.packages("Ecfun")
install.packages("Rtools")

library("Ecdat")
library("Ecfun")

chooseCRANmirror(74)
74

install.packages("Rtools40")

install.packages("Rtools", dependencies = TRUE)

# Confirm and view access to dataset
head(Cigarette)
View(Cigarette)

#	Create a boxplot of the average number of packs per capita by state.
# load libraries to create boxplot
library("ggplot2")
library("dplyr")

ggplot(Cigarette, aes (x=state, y=packpc))+ geom_boxplot()+ "xlab"("State") + "ylab"("Packs Per Capita")


# Determine the Mean of the "packs per capita" by state. 
# which states have the highest number of packs? Which have the lowest?
Cigarette %>% group_by(state) %>% summarise(mean = mean(packpc)) %>% arrange (mean)

Cigarette %>% group_by(state) %>% summarise(mean = mean(packpc)) %>% arrange (desc(mean))

# KY has the highest number of packs per capita at 174.  Utah has the lowest pack per capita ratio at 56.8

# Find the median over all the states of the number of packs per capita for each year.
medianDF <- Cigarette %>% group_by(year) %>% summarize(m.packpc = median(packpc)) 
medianDF
# Plot this median value for the years from 1985 to 1995. What can you say about cigarette usage in these years?
ggplot(medianDF, aes (x=year, y=m.packpc)) + geom_point() + geom_smooth(method=lm)+ "xlab"("Year") + "ylab"("Packs Per Capita")
#Cigarette usage has significantly declined in the period 1985-1995, from 119 packs per capita to 92.8. 
#The following cor.test supports this.

cor.test(medianDF$year, medianDF$m.packpc, method="pearson", use = "complete.obs")
# The p-value is significant at .0000004175, far less than .05
# The correlatioin value is large and very significant at -.9739716 or 97.4%.

#	Create a scatter plot of price per pack vs number of packs per capita for all states and years.
ggplot(Cigarette, aes (x=avgprs, y=packpc)) + geom_point() + geom_smooth(model=lm) + "xlab"("Average Price Per Pack") + "ylab"("Number of Packs Per Capita")

# Are the price and the per capita packs positively correlated, negatively correlated, or uncorrelated? Explain why your answer would be expected.
# Prices are negatively correlated to the per capita packs.  As the number of packs per capita decrease, the price per pack increases.
# This makes sense as the cigarette manufacturers have a smaller pool from which to earn their profit, thus the price/profit per pack must increase.

#	Change your scatter plot to show the points for each year in a different color. Does the relationship between the two variable change over time?
ggplot(Cigarette, aes (x=avgprs, y=packpc, color=year)) + geom_point() + geom_smooth(model=lm) + "xlab"("Average Price Per Pack") + "ylab"("Number of Packs Per Capita")
# The relationship is negatively correlated.  In 1985 sales in packs per capita were higher, resulting in lower prices.
# Sales in packs per capita continued to slide downward, exerting upward pressure on the price, through 1995 as charted.

#	Do a linear regression for these two variables. How much variability does the line explain?
regression <- lm(packpc ~ avgprs, Cigarette)
summary(regression)
# The variability of the line is of medium significance at .3415 or about 34% of the average price as shown by the Averaged R-Square.

# The plot above does not adjust for inflation. You can adjust the price of a pack of cigarettes for inflation by dividing the avgprs variable by the cpi variable. 
InflPrice <- Cigarette %>% mutate(InflPrs = avgprs / cpi)
View(InflPrice)

# Create an adjusted price for each row, then re-do your scatter plot and linear regression using this adjusted price.
mutate(Cigarette,InflPrs = avgprs / cpi)
ggplot(InflPrice, aes (x=InflPrs, y=packpc, color=year)) + geom_point() + geom_smooth(model=lm) + "xlab"("CPI Inflation Adjusted Price Per Pack") + "ylab"("Number of Packs Per Capita")
regression <- lm(packpc ~ Inflprs, InflPrice)
summary(regression)
# The revised linear regression is very similar to that before with the line still showing a 34% variable of pricing on number of packs per capita.

# Create a data frame with just the rows from 1985. 
CigSales1985 <- InflPrice %>% filter (year ==1985)
View(CigSales1985)

# Create a second data frame with just the rows from 1995. 
CigSales1995 <- InflPrice %>% filter (year ==1995)
View(CigSales1995)


# Then, from each of these data frames, get a vector of the number of packs per capita. 
CigSales1985[1:48,"packpc"]
CigSales1995[481:528,"packpc"]

# Use a paired t-test to see if the number of packs per capita in 1995 was significantly different than the number of packs per capita in 1985.
t.test(CigSales1985$packpc, CigSales1995$packpc, paired = TRUE)
# The p-value reflects a significant difference with a p-value < 2.2e-16, a fraction of the p-value < .05 to show signicance.
# There is a significant difference in packs per capita between 1985 & 1995 with the mean of the difference = 25.70863.

# ADDITIONAL QUESTIONS THAT COME TO MIND THAT THE DATASET CAN ANSWER
# 1) What impact does income have on the packs per capita, seeing the large discrepance between KY as the highest and UT as the lowest?
# 2) What is the correlation between the average excise tax per pack (taxs) to the packs per capita at the state level?
# 3) What is the correlation between population and packs per capita?

ggplot(Cigarette, aes (x=state, y=income))+ geom_boxplot()+ "xlab"("State") + "ylab"("Income")
# Determine the median income to help answer the above questions.
MedIncDF <- Cigarette %>% group_by(state) %>% summarise(median = median(income)) %>% arrange (median)
View(MedIncDF)
# Based upon the fact that KY falls 26/48 on income and UT 36/48, I don't see this having much correlation to the packs per capita.

# Proceeding to question two, the correlation between excise tax and packs per capita
ggplot(Cigarette, aes (x=state, y=taxs))+ geom_boxplot()+ "xlab"("State") + "ylab"("Excise Taxes on Pack Per Capita")
#	Create a scatter plot of Income vs number of packs per capita for all states and years.
ggplot(Cigarette, aes (x=taxs, y=packpc, color=year)) + geom_point() + geom_smooth(model=lm) + "xlab"("Excise Tax Per Pack") + "ylab"("Number of Packs Per Capita")
# The higher the taxes per pack, the lower the number of packs per capita sold.  As packs per capita have declined from 1985-1995, excise taxes have increased to compensate.
# While the information is not available in this dataset, it would be interesting to see if marketing costs for cigarettes are higher in those states where excise taxes are higher,
# and what messages the states are propogating to generate higher excise tax revenues, (i.e. follow the money trail).

#	Do a linear regression for these two variables. How much variability does the line explain?
regression <- lm(packpc ~ taxs, Cigarette)
summary(regression)
# The variability of the line is of medium significance at .344 or about 34% of the average price as shown by the Averaged R-Square.

#Perform a paired t-test on the correlation of Excise taxes between 1985 and 1995.
t.test(CigSales1985$taxs, CigSales1995$taxs, paired = TRUE)
# With a p-value < 2.2e-16, far less than our standard of p < .05, there is a significant correlation; the mean of the differences is -27.08229.

# And moving to question three, the correlation between population and packs per capita
ggplot(Cigarette, aes (x=pop, y=packpc, color=year)) + geom_point() + geom_smooth(model=lm) + "xlab"("Population") + "ylab"("Number of Packs Per Capita")
# The scatter plot shows a negative correlation, which stands to reason.  As the packs per capita have decreased between 1985 and 1995,
# population has increased, and "per capita" is essentially a head count of the population, increasing population will "water down" the strength of "Packs Per Capita".


